package com.mindmatrix.ksheerasagara.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ExpenseCategory(val displayName: String, val emoji: String) {
    FODDER("Fodder", "🌾"),
    MEDICAL("Medical", "💊"),
    LABOR("Labor", "👷"),
    ELECTRICITY("Electricity", "⚡"),
    OTHER("Other", "📦")
}

@Entity(tableName = "expenses")
data class ExpenseEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val cowId: Long,
    val cowName: String,
    val category: ExpenseCategory,
    val amount: Double,
    val description: String,
    val date: Long,
    val month: Int,
    val year: Int
)
