package com.mindmatrix.ksheerasagara.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.mindmatrix.ksheerasagara.data.entities.MilkEntry

@Dao
interface MilkEntryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: MilkEntry): Long

    @Delete
    suspend fun delete(entry: MilkEntry)

    @Query("SELECT * FROM milk_entries ORDER BY date DESC")
    fun getAllEntries(): LiveData<List<MilkEntry>>

    @Query("SELECT * FROM milk_entries WHERE month = :month AND year = :year ORDER BY date DESC")
    fun getEntriesForMonth(month: Int, year: Int): LiveData<List<MilkEntry>>

    @Query("SELECT * FROM milk_entries WHERE cowId = :cowId AND month = :month AND year = :year ORDER BY date DESC")
    fun getEntriesForCowMonth(cowId: Long, month: Int, year: Int): LiveData<List<MilkEntry>>

    @Query("SELECT SUM(liters * ratePerLiter) FROM milk_entries WHERE month = :month AND year = :year")
    fun getTotalIncomeForMonth(month: Int, year: Int): LiveData<Double?>

    @Query("SELECT SUM(liters * ratePerLiter) FROM milk_entries WHERE cowId = :cowId AND month = :month AND year = :year")
    fun getTotalIncomeForCowMonth(cowId: Long, month: Int, year: Int): LiveData<Double?>

    @Query("SELECT SUM(liters) FROM milk_entries WHERE cowId = :cowId AND month = :month AND year = :year")
    suspend fun getTotalLitersForCowMonth(cowId: Long, month: Int, year: Int): Double?

    @Query("SELECT * FROM milk_entries WHERE cowId = :cowId ORDER BY date DESC")
    fun getEntriesForCow(cowId: Long): LiveData<List<MilkEntry>>
}
