package com.ksheerasagara.dairy.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ksheerasagara.dairy.viewmodel.DairyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(vm: DairyViewModel) {
    var selectedCowId by remember { mutableStateOf(vm.cows.first().id) }
    var milk by remember { mutableStateOf("10") }
    var fat by remember { mutableStateOf("4.0") }
    var snf by remember { mutableStateOf("8.5") }
    var price by remember { mutableStateOf("35") }
    var feed by remember { mutableStateOf("120") }
    var labour by remember { mutableStateOf("50") }
    var vet by remember { mutableStateOf("20") }
    var other by remember { mutableStateOf("10") }
    var expanded by remember { mutableStateOf(false) }
    var profitResult by remember { mutableStateOf<Double?>(null) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
    ) {
        Box(
            Modifier.fillMaxWidth().background(
                Brush.horizontalGradient(listOf(Color(0xFF2E7D32), Color(0xFF66BB6A)))
            ).padding(20.dp)
        ) {
            Column {
                Text("Welcome, ${vm.userName.value} 👋", color = Color.White, fontSize = 14.sp)
                Text("Dairy Dashboard", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatPill("₹${"%.0f".format(vm.totalProfit())}", "Total Profit")
                    StatPill("${vm.entries.size}", "Entries")
                    StatPill("${vm.cows.size}", "Cows")
                }
            }
        }

        Column(Modifier.padding(16.dp)) {
            SectionCard("New Entry") {
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                    OutlinedTextField(
                        value = vm.cows.find { it.id == selectedCowId }?.name ?: "",
                        onValueChange = {}, readOnly = true,
                        label = { Text("Select Cow") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        vm.cows.forEach { c ->
                            DropdownMenuItem(text = { Text(c.name) }, onClick = {
                                selectedCowId = c.id; expanded = false
                            })
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField(milk, { milk = it }, "Milk (L)", Modifier.weight(1f))
                    NumField(price, { price = it }, "₹/L", Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField(fat, { fat = it }, "Fat %", Modifier.weight(1f))
                    NumField(snf, { snf = it }, "SNF %", Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(12.dp))
            SectionCard("Expenses") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField(feed, { feed = it }, "Feed", Modifier.weight(1f))
                    NumField(labour, { labour = it }, "Labour", Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField(vet, { vet = it }, "Vet", Modifier.weight(1f))
                    NumField(other, { other = it }, "Other", Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    val m = milk.toDoubleOrNull() ?: 0.0
                    val p = price.toDoubleOrNull() ?: 0.0
                    val f = feed.toDoubleOrNull() ?: 0.0
                    val l = labour.toDoubleOrNull() ?: 0.0
                    val v = vet.toDoubleOrNull() ?: 0.0
                    val o = other.toDoubleOrNull() ?: 0.0
                    vm.addEntry(selectedCowId, m, fat.toDoubleOrNull() ?: 0.0, snf.toDoubleOrNull() ?: 0.0, p, f, l, v, o)
                    profitResult = m * p - (f + l + v + o)
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
            ) {
                Icon(Icons.Filled.Calculate, contentDescription = null); Spacer(Modifier.width(8.dp))
                Text("Calculate & Save", fontSize = 16.sp)
            }
            profitResult?.let {
                Spacer(Modifier.height(12.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9))) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Profit for this entry", color = Color(0xFF1B5E20))
                        Text("₹${"%.2f".format(it)}", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                    }
                }
            }
            Spacer(Modifier.height(80.dp))
        }
    }
}

@Composable
private fun StatPill(value: String, label: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.2f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Text(value, color = Color.White, fontWeight = FontWeight.Bold)
            Text(label, color = Color.White.copy(alpha = 0.9f), fontSize = 11.sp)
        }
    }
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = Color(0xFF1B5E20))
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
fun NumField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value, onValueChange = onChange,
        label = { Text(label) },
        singleLine = true, modifier = modifier
    )
}
