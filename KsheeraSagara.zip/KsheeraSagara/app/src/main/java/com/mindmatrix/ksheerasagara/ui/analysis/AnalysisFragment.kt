package com.mindmatrix.ksheerasagara.ui.analysis

import android.graphics.Color
import android.os.Bundle
import android.view.*
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.mindmatrix.ksheerasagara.data.entities.Cow
import com.mindmatrix.ksheerasagara.databinding.FragmentAnalysisBinding
import com.mindmatrix.ksheerasagara.viewmodel.CowViewModel
import com.mindmatrix.ksheerasagara.viewmodel.CowViewModelFactory
import com.mindmatrix.ksheerasagara.viewmodel.DashboardViewModel
import com.mindmatrix.ksheerasagara.viewmodel.DashboardViewModelFactory
import java.util.*

class AnalysisFragment : Fragment() {

    private var _binding: FragmentAnalysisBinding? = null
    private val binding get() = _binding!!
    private lateinit var cowViewModel: CowViewModel
    private lateinit var dashboardViewModel: DashboardViewModel
    private var cows: List<Cow> = emptyList()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAnalysisBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        cowViewModel = ViewModelProvider(this, CowViewModelFactory(requireActivity().application))[CowViewModel::class.java]
        dashboardViewModel = ViewModelProvider(this, DashboardViewModelFactory(requireActivity().application))[DashboardViewModel::class.java]

        setupBarChart()

        cowViewModel.activeCows.observe(viewLifecycleOwner) { cowList ->
            cows = cowList
            if (cowList.isEmpty()) {
                binding.tvNoCows.visibility = View.VISIBLE
                return@observe
            }
            binding.tvNoCows.visibility = View.GONE

            val cowNames = cowList.map { it.name }
            val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, cowNames)
            binding.spinnerCow.adapter = adapter

            binding.spinnerCow.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    loadCowAnalysis(cowList[pos])
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }

            loadCowAnalysis(cowList[0])
        }
    }

    private fun setupBarChart() {
        binding.barChart.apply {
            description.isEnabled = false
            setDrawGridBackground(false)
            legend.isEnabled = true
            axisRight.isEnabled = false
            xAxis.granularity = 1f
            xAxis.setDrawGridLines(false)
            axisLeft.axisMinimum = 0f
        }
    }

    private fun loadCowAnalysis(cow: Cow) {
        val cal = Calendar.getInstance()
        val month = cal.get(Calendar.MONTH) + 1
        val year = cal.get(Calendar.YEAR)

        dashboardViewModel.repository.getTotalIncomeForCowMonth(cow.id, month, year).observe(viewLifecycleOwner) { income ->
            dashboardViewModel.repository.getTotalExpensesForCowMonth(cow.id, month, year).observe(viewLifecycleOwner) { expenses ->
                val inc = income ?: 0.0
                val exp = expenses ?: 0.0
                val profit = inc - exp

                binding.tvCowIncome.text = "₹%.2f".format(inc)
                binding.tvCowExpenses.text = "₹%.2f".format(exp)
                binding.tvCowProfit.text = "₹%.2f".format(profit)

                if (profit >= 0) {
                    binding.tvCowProfit.setTextColor(Color.parseColor("#2E7D32"))
                    binding.tvProfitabilityLabel.text = "✅ ${cow.name} is PROFITABLE"
                    binding.tvProfitabilityLabel.setTextColor(Color.parseColor("#2E7D32"))
                } else {
                    binding.tvCowProfit.setTextColor(Color.parseColor("#C62828"))
                    binding.tvProfitabilityLabel.text = "⚠️ ${cow.name} is NOT PROFITABLE"
                    binding.tvProfitabilityLabel.setTextColor(Color.parseColor("#C62828"))
                }

                updateBarChart(inc, exp, profit, cow.name)
            }
        }
    }

    private fun updateBarChart(income: Double, expenses: Double, profit: Double, cowName: String) {
        val incomeEntries = listOf(BarEntry(0f, income.toFloat()))
        val expenseEntries = listOf(BarEntry(1f, expenses.toFloat()))
        val profitEntries = listOf(BarEntry(2f, maxOf(profit.toFloat(), 0f)))

        val incomeSet = BarDataSet(incomeEntries, "Income").apply { color = Color.parseColor("#4CAF50"); valueTextSize = 11f }
        val expenseSet = BarDataSet(expenseEntries, "Expenses").apply { color = Color.parseColor("#F44336"); valueTextSize = 11f }
        val profitSet = BarDataSet(profitEntries, "Profit").apply { color = Color.parseColor("#2196F3"); valueTextSize = 11f }

        binding.barChart.xAxis.valueFormatter = IndexAxisValueFormatter(listOf("Income", "Expenses", "Profit"))
        binding.barChart.data = BarData(incomeSet, expenseSet, profitSet).apply { barWidth = 0.25f }
        binding.barChart.groupBars(0f, 0.08f, 0.03f)
        binding.barChart.invalidate()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
