package com.mindmatrix.ksheerasagara

import android.app.Application
import com.mindmatrix.ksheerasagara.data.database.AppDatabase
import com.mindmatrix.ksheerasagara.data.repository.DairyRepository

class KsheeraApp : Application() {

    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy {
        DairyRepository(
            database.cowDao(),
            database.milkEntryDao(),
            database.expenseDao()
        )
    }
}
