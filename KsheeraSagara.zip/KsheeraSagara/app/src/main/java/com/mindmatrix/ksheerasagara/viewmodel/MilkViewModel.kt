package com.mindmatrix.ksheerasagara.viewmodel

import android.app.Application
import androidx.lifecycle.*
import com.mindmatrix.ksheerasagara.KsheeraApp
import com.mindmatrix.ksheerasagara.data.entities.Cow
import com.mindmatrix.ksheerasagara.data.entities.MilkEntry
import com.mindmatrix.ksheerasagara.data.repository.DairyRepository
import kotlinx.coroutines.launch
import java.util.Calendar

class MilkViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: DairyRepository = (application as KsheeraApp).repository

    val activeCows: LiveData<List<Cow>> = repository.activeCows
    val allMilkEntries: LiveData<List<MilkEntry>> = repository.getAllMilkEntries()

    fun insertMilkEntry(entry: MilkEntry) = viewModelScope.launch {
        repository.insertMilkEntry(entry)
    }

    fun deleteMilkEntry(entry: MilkEntry) = viewModelScope.launch {
        repository.deleteMilkEntry(entry)
    }

    fun getEntriesForMonth(month: Int, year: Int) = repository.getEntriesForMonth(month, year)
}

class MilkViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MilkViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MilkViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
