package com.mindmatrix.ksheerasagara.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.mindmatrix.ksheerasagara.data.dao.CowDao
import com.mindmatrix.ksheerasagara.data.dao.ExpenseDao
import com.mindmatrix.ksheerasagara.data.dao.MilkEntryDao
import com.mindmatrix.ksheerasagara.data.entities.Cow
import com.mindmatrix.ksheerasagara.data.entities.ExpenseEntry
import com.mindmatrix.ksheerasagara.data.entities.MilkEntry

@Database(
    entities = [Cow::class, MilkEntry::class, ExpenseEntry::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun cowDao(): CowDao
    abstract fun milkEntryDao(): MilkEntryDao
    abstract fun expenseDao(): ExpenseDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ksheera_sagara_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
