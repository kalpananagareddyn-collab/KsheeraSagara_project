package com.mindmatrix.ksheerasagara.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.mindmatrix.ksheerasagara.data.entities.Cow

@Dao
interface CowDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(cow: Cow): Long

    @Update
    suspend fun update(cow: Cow)

    @Delete
    suspend fun delete(cow: Cow)

    @Query("SELECT * FROM cows WHERE isActive = 1 ORDER BY name ASC")
    fun getActiveCows(): LiveData<List<Cow>>

    @Query("SELECT * FROM cows ORDER BY name ASC")
    fun getAllCows(): LiveData<List<Cow>>

    @Query("SELECT * FROM cows WHERE id = :id")
    suspend fun getCowById(id: Long): Cow?
}
