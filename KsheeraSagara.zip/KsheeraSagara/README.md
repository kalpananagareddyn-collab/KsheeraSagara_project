# Ksheera-Sagara 🐄
## Dairy Profit/Loss Calculator
### MindMatrix VTU Internship Program — Project #29

---

## How to Open in Android Studio

1. **Clone / Extract** this ZIP to your laptop
2. Open **Android Studio** → `File → Open` → select the `KsheeraSagara` folder
3. Wait for Gradle sync to complete (requires internet for first-time dependency download)
4. Connect an Android device or start an emulator (API 26+)
5. Click **Run ▶**

---

## Features

| Feature | Description |
|---|---|
| 🐄 My Cows | Add/edit/delete cows in your herd |
| 🥛 Milk Log | Record daily milk slip (Liters, Fat%, SNF%, Rate) |
| 💸 Expense Log | Log Fodder / Medical / Labor / Electricity / Other |
| 📊 Dashboard | Green/Red profit indicator + pie chart breakdown |
| 📈 Cow Analysis | Per-cow profitability with bar chart |
| 📋 Summary | Monthly financial summary — shareable via WhatsApp/Email |

---

## Tech Stack
- **Language**: Kotlin
- **Architecture**: MVVM (ViewModel + LiveData)
- **Database**: Room DB (local SQLite)
- **Charts**: MPAndroidChart
- **UI**: Material Design 3
- **Navigation**: Jetpack Navigation Component

---

## Formula
```
Net Profit = Total Income (Milk Sales) − Total Expenses (Fodder + Medical + Labor + Electricity)
```
