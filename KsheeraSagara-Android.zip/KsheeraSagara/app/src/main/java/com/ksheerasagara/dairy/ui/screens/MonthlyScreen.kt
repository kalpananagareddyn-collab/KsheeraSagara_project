package com.ksheerasagara.dairy.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ksheerasagara.dairy.viewmodel.DairyViewModel

@Composable
fun MonthlyScreen(vm: DairyViewModel) {
    val ctx = LocalContext.current
    val months = vm.last6MonthProfits()
    val max = months.maxOfOrNull { it.second }?.coerceAtLeast(1.0) ?: 1.0

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Monthly Summary", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20), modifier = Modifier.weight(1f))
            IconButton(onClick = { vm.logout() }) { Icon(Icons.Filled.Logout, contentDescription = "Logout") }
        }
        Spacer(Modifier.height(12.dp))

        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp)) {
                Text("6-Month Profit Trend", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(16.dp))
                Row(
                    Modifier.fillMaxWidth().height(180.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    months.forEach { (label, value) ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("₹${"%.0f".format(value)}", fontSize = 10.sp, color = Color.Gray)
                            Spacer(Modifier.height(4.dp))
                            val h = ((value / max) * 140).toFloat().coerceIn(8f, 140f)
                            Box(
                                Modifier.width(28.dp).height(h.dp)
                                    .background(Color(0xFF2E7D32), RoundedCornerShape(6.dp))
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(label, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Mini("Total Revenue", "₹${"%.0f".format(vm.totalRevenue())}", Modifier.weight(1f))
            Mini("Total Expense", "₹${"%.0f".format(vm.totalExpense())}", Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Mini("Net Profit", "₹${"%.0f".format(vm.totalProfit())}", Modifier.fillMaxWidth(), Color(0xFF2E7D32))

        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                val report = buildString {
                    appendLine("Ksheera-Sagara Monthly Report")
                    appendLine("User: ${vm.userName.value}")
                    appendLine("Total Profit: ₹${"%.2f".format(vm.totalProfit())}")
                    appendLine("Total Revenue: ₹${"%.2f".format(vm.totalRevenue())}")
                    appendLine("Total Expense: ₹${"%.2f".format(vm.totalExpense())}")
                    appendLine()
                    appendLine("Monthly Breakdown:")
                    months.forEach { (m, v) -> appendLine("$m: ₹${"%.2f".format(v)}") }
                }
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "Dairy Report")
                    putExtra(Intent.EXTRA_TEXT, report)
                }
                ctx.startActivity(Intent.createChooser(intent, "Share Report"))
                Toast.makeText(ctx, "Report generated", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
        ) {
            Icon(Icons.Filled.Download, contentDescription = null); Spacer(Modifier.width(8.dp))
            Text("Generate Report", fontSize = 16.sp)
        }
        Spacer(Modifier.height(80.dp))
    }
}

@Composable
private fun Mini(label: String, value: String, modifier: Modifier = Modifier, valueColor: Color = Color(0xFF1B5E20)) {
    Card(modifier = modifier, shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Color.Gray, fontSize = 12.sp)
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = valueColor)
        }
    }
}
