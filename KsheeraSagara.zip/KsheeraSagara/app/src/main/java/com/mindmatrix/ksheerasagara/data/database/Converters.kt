package com.mindmatrix.ksheerasagara.data.database

import androidx.room.TypeConverter
import com.mindmatrix.ksheerasagara.data.entities.ExpenseCategory

class Converters {
    @TypeConverter
    fun fromExpenseCategory(category: ExpenseCategory): String = category.name

    @TypeConverter
    fun toExpenseCategory(name: String): ExpenseCategory = ExpenseCategory.valueOf(name)
}
