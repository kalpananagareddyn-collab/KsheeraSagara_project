package com.mindmatrix.ksheerasagara.ui.summary

import android.content.Intent
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.mindmatrix.ksheerasagara.data.entities.ExpenseCategory
import com.mindmatrix.ksheerasagara.databinding.FragmentSummaryBinding
import com.mindmatrix.ksheerasagara.viewmodel.DashboardViewModel
import com.mindmatrix.ksheerasagara.viewmodel.DashboardViewModelFactory
import java.text.SimpleDateFormat
import java.util.*

class SummaryFragment : Fragment() {

    private var _binding: FragmentSummaryBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: DashboardViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSummaryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(this, DashboardViewModelFactory(requireActivity().application))[DashboardViewModel::class.java]

        val cal = Calendar.getInstance()
        val monthName = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(cal.time)
        binding.tvSummaryMonth.text = "📋 Summary: $monthName"

        observeData()

        binding.btnShare.setOnClickListener { shareSummary() }
    }

    private fun observeData() {
        viewModel.totalIncome.observe(viewLifecycleOwner) { income ->
            binding.tvSummaryIncome.text = "₹%.2f".format(income ?: 0.0)
            updateProfit()
        }

        viewModel.totalExpenses.observe(viewLifecycleOwner) { expenses ->
            binding.tvSummaryExpenses.text = "₹%.2f".format(expenses ?: 0.0)
            updateProfit()
        }

        viewModel.activeCows.observe(viewLifecycleOwner) { cows ->
            binding.tvSummaryCows.text = "${cows.size}"
        }

        // Category breakdown
        ExpenseCategory.values().forEachIndexed { idx, cat ->
            viewModel.getCategoryExpenses(cat).observe(viewLifecycleOwner) { amount ->
                when (cat) {
                    ExpenseCategory.FODDER -> binding.tvFodderAmt.text = "₹%.2f".format(amount ?: 0.0)
                    ExpenseCategory.MEDICAL -> binding.tvMedicalAmt.text = "₹%.2f".format(amount ?: 0.0)
                    ExpenseCategory.LABOR -> binding.tvLaborAmt.text = "₹%.2f".format(amount ?: 0.0)
                    ExpenseCategory.ELECTRICITY -> binding.tvElectricityAmt.text = "₹%.2f".format(amount ?: 0.0)
                    ExpenseCategory.OTHER -> binding.tvOtherAmt.text = "₹%.2f".format(amount ?: 0.0)
                }
            }
        }
    }

    private fun updateProfit() {
        val income = viewModel.totalIncome.value ?: 0.0
        val expenses = viewModel.totalExpenses.value ?: 0.0
        val profit = income - expenses
        binding.tvSummaryProfit.text = "₹%.2f".format(profit)

        val suggestion = when {
            profit > 5000 -> "🌟 Excellent! Consider expanding your herd."
            profit > 0 -> "✅ Good job! Try reducing fodder cost with home-grown feed."
            profit > -2000 -> "⚠️ Marginal loss. Review your fodder expenses."
            else -> "🔴 Significant loss. Consider selling non-productive cows."
        }
        binding.tvSuggestion.text = suggestion
    }

    private fun shareSummary() {
        val income = viewModel.totalIncome.value ?: 0.0
        val expenses = viewModel.totalExpenses.value ?: 0.0
        val profit = income - expenses
        val cal = Calendar.getInstance()
        val monthName = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(cal.time)

        val text = """
🐄 Ksheera-Sagara Monthly Report
📅 $monthName

💰 Total Income:  ₹${String.format("%.2f", income)}
💸 Total Expenses: ₹${String.format("%.2f", expenses)}
📊 Net Profit/Loss: ₹${String.format("%.2f", profit)}

Expense Breakdown:
🌾 Fodder:      ₹${binding.tvFodderAmt.text}
💊 Medical:     ₹${binding.tvMedicalAmt.text}
👷 Labor:       ₹${binding.tvLaborAmt.text}
⚡ Electricity: ₹${binding.tvElectricityAmt.text}
📦 Other:       ₹${binding.tvOtherAmt.text}

${binding.tvSuggestion.text}

— Powered by Ksheera-Sagara (MindMatrix VTU Internship)
        """.trimIndent()

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            putExtra(Intent.EXTRA_SUBJECT, "Dairy Monthly Financial Summary – $monthName")
        }
        startActivity(Intent.createChooser(intent, "Share Summary via"))
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
