package com.mindmatrix.ksheerasagara.viewmodel

import android.app.Application
import androidx.lifecycle.*
import com.mindmatrix.ksheerasagara.KsheeraApp
import com.mindmatrix.ksheerasagara.data.entities.Cow
import com.mindmatrix.ksheerasagara.data.repository.DairyRepository
import kotlinx.coroutines.launch

class CowViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: DairyRepository = (application as KsheeraApp).repository

    val allCows: LiveData<List<Cow>> = repository.allCows
    val activeCows: LiveData<List<Cow>> = repository.activeCows

    fun insertCow(cow: Cow) = viewModelScope.launch {
        repository.insertCow(cow)
    }

    fun updateCow(cow: Cow) = viewModelScope.launch {
        repository.updateCow(cow)
    }

    fun deleteCow(cow: Cow) = viewModelScope.launch {
        repository.deleteCow(cow)
    }
}

class CowViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CowViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return CowViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
