package com.mindmatrix.ksheerasagara.viewmodel

import android.app.Application
import androidx.lifecycle.*
import com.mindmatrix.ksheerasagara.KsheeraApp
import com.mindmatrix.ksheerasagara.data.entities.Cow
import com.mindmatrix.ksheerasagara.data.entities.ExpenseCategory
import com.mindmatrix.ksheerasagara.data.repository.DairyRepository
import java.util.Calendar

class DashboardViewModel(application: Application) : AndroidViewModel(application) {

    val repository: DairyRepository = (application as KsheeraApp).repository

    private val _currentMonth = MutableLiveData<Int>()
    private val _currentYear = MutableLiveData<Int>()

    init {
        val cal = Calendar.getInstance()
        _currentMonth.value = cal.get(Calendar.MONTH) + 1
        _currentYear.value = cal.get(Calendar.YEAR)
    }

    val currentMonth: LiveData<Int> = _currentMonth
    val currentYear: LiveData<Int> = _currentYear

    val activeCows: LiveData<List<Cow>> = repository.activeCows

    val totalIncome: LiveData<Double?> = _currentMonth.switchMap { month ->
        _currentYear.switchMap { year ->
            repository.getTotalIncomeForMonth(month, year)
        }
    }

    val totalExpenses: LiveData<Double?> = _currentMonth.switchMap { month ->
        _currentYear.switchMap { year ->
            repository.getTotalExpensesForMonth(month, year)
        }
    }

    fun setMonthYear(month: Int, year: Int) {
        _currentMonth.value = month
        _currentYear.value = year
    }

    fun getCategoryExpenses(category: ExpenseCategory) =
        repository.getExpensesByCategory(category, _currentMonth.value ?: 1, _currentYear.value ?: 2024)
}

class DashboardViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DashboardViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return DashboardViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
