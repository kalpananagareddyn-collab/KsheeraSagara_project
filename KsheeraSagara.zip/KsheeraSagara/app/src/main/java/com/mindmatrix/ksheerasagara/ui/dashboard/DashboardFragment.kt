package com.mindmatrix.ksheerasagara.ui.dashboard

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.formatter.PercentFormatter
import com.mindmatrix.ksheerasagara.R
import com.mindmatrix.ksheerasagara.data.entities.ExpenseCategory
import com.mindmatrix.ksheerasagara.databinding.FragmentDashboardBinding
import com.mindmatrix.ksheerasagara.viewmodel.DashboardViewModel
import com.mindmatrix.ksheerasagara.viewmodel.DashboardViewModelFactory
import java.text.SimpleDateFormat
import java.util.*

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: DashboardViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(
            this, DashboardViewModelFactory(requireActivity().application)
        )[DashboardViewModel::class.java]

        setupChart()
        observeData()

        val cal = Calendar.getInstance()
        val monthName = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(cal.time)
        binding.tvMonthTitle.text = monthName
    }

    private fun observeData() {
        viewModel.totalIncome.observe(viewLifecycleOwner) { income ->
            val inc = income ?: 0.0
            binding.tvIncomeValue.text = "₹%.2f".format(inc)
            updateNetProfit()
            updateChart()
        }

        viewModel.totalExpenses.observe(viewLifecycleOwner) { expenses ->
            val exp = expenses ?: 0.0
            binding.tvExpenseValue.text = "₹%.2f".format(exp)
            updateNetProfit()
            updateChart()
        }

        viewModel.activeCows.observe(viewLifecycleOwner) { cows ->
            binding.tvCowCount.text = "${cows.size} Cows"
        }
    }

    private fun updateNetProfit() {
        val income = viewModel.totalIncome.value ?: 0.0
        val expenses = viewModel.totalExpenses.value ?: 0.0
        val profit = income - expenses
        binding.tvProfitValue.text = "₹%.2f".format(profit)

        if (profit >= 0) {
            binding.tvProfitValue.setTextColor(Color.parseColor("#2E7D32"))
            binding.tvProfitLabel.text = "Net Profit 📈"
            binding.cardProfit.setCardBackgroundColor(Color.parseColor("#E8F5E9"))
            binding.tvHealthIndicator.text = "🟢 Financially Healthy"
            binding.tvHealthIndicator.setTextColor(Color.parseColor("#2E7D32"))
        } else {
            binding.tvProfitValue.setTextColor(Color.parseColor("#C62828"))
            binding.tvProfitLabel.text = "Net Loss 📉"
            binding.cardProfit.setCardBackgroundColor(Color.parseColor("#FFEBEE"))
            binding.tvHealthIndicator.text = "🔴 Operating at a Loss"
            binding.tvHealthIndicator.setTextColor(Color.parseColor("#C62828"))
        }
    }

    private fun setupChart() {
        binding.pieChart.apply {
            description.isEnabled = false
            isRotationEnabled = true
            setUsePercentValues(true)
            setDrawEntryLabels(false)
            legend.isEnabled = true
            setHoleColor(Color.TRANSPARENT)
            holeRadius = 55f
            transparentCircleRadius = 60f
            setCenterTextSize(14f)
            setCenterText("Expenses\nBreakdown")
            setCenterTextColor(Color.parseColor("#37474F"))
        }
    }

    private fun updateChart() {
        val month = viewModel.currentMonth.value ?: 1
        val year = viewModel.currentYear.value ?: 2024

        val categories = ExpenseCategory.values()
        val entries = ArrayList<PieEntry>()
        val colors = listOf(
            Color.parseColor("#4CAF50"),
            Color.parseColor("#2196F3"),
            Color.parseColor("#FF9800"),
            Color.parseColor("#9C27B0"),
            Color.parseColor("#F44336")
        )

        // observe each category and build chart
        viewModel.getCategoryExpenses(ExpenseCategory.FODDER).observe(viewLifecycleOwner) { fodder ->
            viewModel.getCategoryExpenses(ExpenseCategory.MEDICAL).observe(viewLifecycleOwner) { medical ->
                viewModel.getCategoryExpenses(ExpenseCategory.LABOR).observe(viewLifecycleOwner) { labor ->
                    viewModel.getCategoryExpenses(ExpenseCategory.ELECTRICITY).observe(viewLifecycleOwner) { electricity ->
                        viewModel.getCategoryExpenses(ExpenseCategory.OTHER).observe(viewLifecycleOwner) { other ->
                            val dataEntries = ArrayList<PieEntry>()
                            val dataColors = ArrayList<Int>()

                            val values = listOf(
                                Pair(fodder ?: 0.0, "🌾 Fodder"),
                                Pair(medical ?: 0.0, "💊 Medical"),
                                Pair(labor ?: 0.0, "👷 Labor"),
                                Pair(electricity ?: 0.0, "⚡ Electricity"),
                                Pair(other ?: 0.0, "📦 Other")
                            )

                            values.forEachIndexed { idx, (amount, label) ->
                                if (amount > 0) {
                                    dataEntries.add(PieEntry(amount.toFloat(), label))
                                    dataColors.add(colors[idx])
                                }
                            }

                            if (dataEntries.isEmpty()) {
                                dataEntries.add(PieEntry(1f, "No Data"))
                                dataColors.add(Color.LTGRAY)
                            }

                            val dataSet = PieDataSet(dataEntries, "").apply {
                                this.colors = dataColors
                                valueTextSize = 12f
                                valueTextColor = Color.WHITE
                                sliceSpace = 3f
                            }

                            val pieData = PieData(dataSet).apply {
                                setValueFormatter(PercentFormatter(binding.pieChart))
                            }

                            binding.pieChart.data = pieData
                            binding.pieChart.invalidate()
                        }
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
