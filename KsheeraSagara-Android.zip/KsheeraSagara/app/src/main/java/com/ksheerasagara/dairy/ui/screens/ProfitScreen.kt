package com.ksheerasagara.dairy.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ksheerasagara.dairy.viewmodel.DairyViewModel

@Composable
fun ProfitScreen(vm: DairyViewModel) {
    val totals = vm.expenseByCategory()
    val sum = totals.values.sum().takeIf { it > 0 } ?: 1.0
    val colors = mapOf(
        "Feed" to Color(0xFF2E7D32),
        "Labour" to Color(0xFF66BB6A),
        "Vet" to Color(0xFFFFB300),
        "Other" to Color(0xFFEF6C00),
    )

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Profit Analytics", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
        Spacer(Modifier.height(12.dp))

        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(200.dp)) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        var startAngle = -90f
                        totals.forEach { (cat, v) ->
                            val sweep = (v / sum * 360.0).toFloat()
                            drawArc(
                                color = colors[cat] ?: Color.Gray,
                                startAngle = startAngle,
                                sweepAngle = sweep,
                                useCenter = false,
                                style = Stroke(width = 50f),
                                size = Size(size.width - 40f, size.height - 40f),
                                topLeft = androidx.compose.ui.geometry.Offset(20f, 20f)
                            )
                            startAngle += sweep
                        }
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Net Profit", fontSize = 12.sp, color = Color.Gray)
                        Text("₹${"%.0f".format(vm.totalProfit())}", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                    }
                }
                Spacer(Modifier.height(16.dp))
                totals.forEach { (cat, v) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(12.dp).clip(CircleShape).background(colors[cat] ?: Color.Gray))
                        Spacer(Modifier.width(8.dp))
                        Text(cat, modifier = Modifier.weight(1f))
                        Text("₹${"%.0f".format(v)}", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            InfoCard("Revenue", "₹${"%.0f".format(vm.totalRevenue())}", Color(0xFF2E7D32), Modifier.weight(1f))
            InfoCard("Expense", "₹${"%.0f".format(vm.totalExpense())}", Color(0xFFEF6C00), Modifier.weight(1f))
        }
        Spacer(Modifier.height(80.dp))
    }
}

@Composable
private fun InfoCard(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, color = Color.Gray, fontSize = 12.sp)
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}
