package com.mindmatrix.ksheerasagara.ui.income

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.mindmatrix.ksheerasagara.data.entities.MilkEntry
import com.mindmatrix.ksheerasagara.databinding.ItemMilkEntryBinding
import java.text.SimpleDateFormat
import java.util.*

class MilkEntryAdapter(private val onDelete: (MilkEntry) -> Unit) :
    ListAdapter<MilkEntry, MilkEntryAdapter.ViewHolder>(DIFF_CALLBACK) {

    inner class ViewHolder(private val binding: ItemMilkEntryBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(entry: MilkEntry) {
            val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
            binding.tvDate.text = sdf.format(Date(entry.date))
            binding.tvCowName.text = "🐄 ${entry.cowName}"
            binding.tvLiters.text = "${entry.liters}L"
            binding.tvFat.text = "Fat: ${entry.fatPercent}%"
            binding.tvSnf.text = "SNF: ${entry.snfPercent}%"
            binding.tvPayment.text = "₹%.2f".format(entry.totalPayment)
            binding.tvRate.text = "@ ₹${entry.ratePerLiter}/L"
            binding.btnDelete.setOnClickListener { onDelete(entry) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemMilkEntryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<MilkEntry>() {
            override fun areItemsTheSame(a: MilkEntry, b: MilkEntry) = a.id == b.id
            override fun areContentsTheSame(a: MilkEntry, b: MilkEntry) = a == b
        }
    }
}
