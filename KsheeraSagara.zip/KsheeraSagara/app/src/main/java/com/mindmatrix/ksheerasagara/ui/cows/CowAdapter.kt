package com.mindmatrix.ksheerasagara.ui.cows

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.mindmatrix.ksheerasagara.data.entities.Cow
import com.mindmatrix.ksheerasagara.databinding.ItemCowBinding
import java.text.SimpleDateFormat
import java.util.*

class CowAdapter(
    private val onEdit: (Cow) -> Unit,
    private val onDelete: (Cow) -> Unit
) : ListAdapter<Cow, CowAdapter.ViewHolder>(DIFF) {

    inner class ViewHolder(private val b: ItemCowBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(cow: Cow) {
            b.tvCowName.text = cow.name
            b.tvBreed.text = "Breed: ${cow.breed}"
            b.tvAge.text = "Age: ${cow.age} yrs"
            val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
            b.tvAdded.text = "Added: ${sdf.format(Date(cow.addedDate))}"
            b.btnEdit.setOnClickListener { onEdit(cow) }
            b.btnDelete.setOnClickListener { onDelete(cow) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemCowBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(h: ViewHolder, pos: Int) = h.bind(getItem(pos))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Cow>() {
            override fun areItemsTheSame(a: Cow, b: Cow) = a.id == b.id
            override fun areContentsTheSame(a: Cow, b: Cow) = a == b
        }
    }
}
