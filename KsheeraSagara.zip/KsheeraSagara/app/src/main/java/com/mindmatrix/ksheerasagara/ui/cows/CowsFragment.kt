package com.mindmatrix.ksheerasagara.ui.cows

import android.os.Bundle
import android.view.*
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.mindmatrix.ksheerasagara.R
import com.mindmatrix.ksheerasagara.data.entities.Cow
import com.mindmatrix.ksheerasagara.databinding.FragmentCowsBinding
import com.mindmatrix.ksheerasagara.viewmodel.CowViewModel
import com.mindmatrix.ksheerasagara.viewmodel.CowViewModelFactory

class CowsFragment : Fragment() {

    private var _binding: FragmentCowsBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: CowViewModel
    private lateinit var adapter: CowAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentCowsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(this, CowViewModelFactory(requireActivity().application))[CowViewModel::class.java]

        adapter = CowAdapter(
            onEdit = { cow -> showEditDialog(cow) },
            onDelete = { cow ->
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle("Remove Cow")
                    .setMessage("Remove ${cow.name} from your herd?")
                    .setPositiveButton("Remove") { _, _ -> viewModel.deleteCow(cow) }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        )

        binding.rvCows.layoutManager = LinearLayoutManager(requireContext())
        binding.rvCows.adapter = adapter

        viewModel.allCows.observe(viewLifecycleOwner) { cows ->
            adapter.submitList(cows)
            binding.tvEmptyState.visibility = if (cows.isEmpty()) View.VISIBLE else View.GONE
            binding.tvCowCount.text = "${cows.size} cow(s) in herd"
        }

        binding.fabAddCow.setOnClickListener { showAddCowDialog() }
    }

    private fun showAddCowDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_cow, null)
        val etName = dialogView.findViewById<EditText>(R.id.etCowName)
        val etBreed = dialogView.findViewById<EditText>(R.id.etBreed)
        val etAge = dialogView.findViewById<EditText>(R.id.etAge)

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("🐄 Add New Cow")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val name = etName.text.toString().trim()
                val breed = etBreed.text.toString().trim()
                val age = etAge.text.toString().toIntOrNull() ?: 0
                if (name.isNotEmpty()) {
                    viewModel.insertCow(Cow(name = name, breed = breed.ifEmpty { "Mixed" }, age = age))
                    Snackbar.make(binding.root, "$name added to your herd! 🐄", Snackbar.LENGTH_SHORT).show()
                } else {
                    Snackbar.make(binding.root, "Please enter cow name", Snackbar.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showEditDialog(cow: Cow) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_cow, null)
        val etName = dialogView.findViewById<EditText>(R.id.etCowName)
        val etBreed = dialogView.findViewById<EditText>(R.id.etBreed)
        val etAge = dialogView.findViewById<EditText>(R.id.etAge)
        etName.setText(cow.name); etBreed.setText(cow.breed); etAge.setText(cow.age.toString())

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("✏️ Edit ${cow.name}")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val name = etName.text.toString().trim()
                val breed = etBreed.text.toString().trim()
                val age = etAge.text.toString().toIntOrNull() ?: 0
                if (name.isNotEmpty()) viewModel.updateCow(cow.copy(name = name, breed = breed, age = age))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
