package com.ksheerasagara.dairy.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ksheerasagara.dairy.viewmodel.DairyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CowAnalysisScreen(vm: DairyViewModel) {
    var showDialog by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    val ranking = vm.profitByCow()
    val best = ranking.firstOrNull()
    val max = ranking.maxOfOrNull { it.second }?.coerceAtLeast(1.0) ?: 1.0

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showDialog = true }, containerColor = Color(0xFF2E7D32)) {
                Icon(Icons.Filled.Add, contentDescription = "Add Cow", tint = Color.White)
            }
        },
        containerColor = Color.Transparent
    ) { p ->
        Column(Modifier.padding(p).padding(16.dp).fillMaxSize()) {
            Text("Cow Analysis", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
            Spacer(Modifier.height(12.dp))
            best?.let { (cow, profit) ->
                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1))) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = Color(0xFFFFB300), modifier = Modifier.size(40.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Top Performer", fontSize = 12.sp, color = Color.Gray)
                            Text(cow.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text("₹${"%.0f".format(profit)} profit", color = Color(0xFF2E7D32))
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(ranking) { (cow, profit) ->
                    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Pets, contentDescription = null, tint = Color(0xFF2E7D32))
                                Spacer(Modifier.width(8.dp))
                                Text(cow.name, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                Text("₹${"%.0f".format(profit)}", fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                            }
                            Spacer(Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { (profit / max).toFloat().coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxWidth().height(8.dp),
                                color = Color(0xFF66BB6A),
                                trackColor = Color(0xFFE0E0E0)
                            )
                            Spacer(Modifier.height(6.dp))
                            Text("Milk: ${cow.milkLiters}L • Fat: ${cow.fatPct}% • SNF: ${cow.snfPct}%", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Add New Cow") },
            text = {
                OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("Cow Name") })
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.addCow(newName); newName = ""; showDialog = false
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text("Cancel") } }
        )
    }
}
