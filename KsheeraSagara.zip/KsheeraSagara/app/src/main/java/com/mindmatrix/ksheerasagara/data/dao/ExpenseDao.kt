package com.mindmatrix.ksheerasagara.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.mindmatrix.ksheerasagara.data.entities.ExpenseCategory
import com.mindmatrix.ksheerasagara.data.entities.ExpenseEntry

@Dao
interface ExpenseDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: ExpenseEntry): Long

    @Delete
    suspend fun delete(entry: ExpenseEntry)

    @Query("SELECT * FROM expenses ORDER BY date DESC")
    fun getAllExpenses(): LiveData<List<ExpenseEntry>>

    @Query("SELECT * FROM expenses WHERE month = :month AND year = :year ORDER BY date DESC")
    fun getExpensesForMonth(month: Int, year: Int): LiveData<List<ExpenseEntry>>

    @Query("SELECT SUM(amount) FROM expenses WHERE month = :month AND year = :year")
    fun getTotalExpensesForMonth(month: Int, year: Int): LiveData<Double?>

    @Query("SELECT SUM(amount) FROM expenses WHERE cowId = :cowId AND month = :month AND year = :year")
    fun getTotalExpensesForCowMonth(cowId: Long, month: Int, year: Int): LiveData<Double?>

    @Query("SELECT SUM(amount) FROM expenses WHERE category = :category AND month = :month AND year = :year")
    fun getExpensesByCategory(category: ExpenseCategory, month: Int, year: Int): LiveData<Double?>

    @Query("SELECT * FROM expenses WHERE cowId = :cowId AND month = :month AND year = :year ORDER BY date DESC")
    fun getExpensesForCowMonth(cowId: Long, month: Int, year: Int): LiveData<List<ExpenseEntry>>
}
