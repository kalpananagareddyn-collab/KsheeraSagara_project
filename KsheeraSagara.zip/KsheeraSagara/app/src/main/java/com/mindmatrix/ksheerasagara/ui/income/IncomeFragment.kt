package com.mindmatrix.ksheerasagara.ui.income

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.mindmatrix.ksheerasagara.R
import com.mindmatrix.ksheerasagara.data.entities.Cow
import com.mindmatrix.ksheerasagara.data.entities.MilkEntry
import com.mindmatrix.ksheerasagara.databinding.FragmentIncomeBinding
import com.mindmatrix.ksheerasagara.viewmodel.MilkViewModel
import com.mindmatrix.ksheerasagara.viewmodel.MilkViewModelFactory
import java.util.*

class IncomeFragment : Fragment() {

    private var _binding: FragmentIncomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: MilkViewModel
    private lateinit var adapter: MilkEntryAdapter
    private var cows: List<Cow> = emptyList()
    private var selectedDate = Calendar.getInstance()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentIncomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(this, MilkViewModelFactory(requireActivity().application))[MilkViewModel::class.java]

        adapter = MilkEntryAdapter { entry ->
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Delete Entry")
                .setMessage("Delete this milk entry?")
                .setPositiveButton("Delete") { _, _ -> viewModel.deleteMilkEntry(entry) }
                .setNegativeButton("Cancel", null)
                .show()
        }

        binding.rvMilkEntries.layoutManager = LinearLayoutManager(requireContext())
        binding.rvMilkEntries.adapter = adapter

        val cal = Calendar.getInstance()
        viewModel.getEntriesForMonth(cal.get(Calendar.MONTH) + 1, cal.get(Calendar.YEAR)).observe(viewLifecycleOwner) { entries ->
            adapter.submitList(entries)
            binding.tvEmptyState.visibility = if (entries.isEmpty()) View.VISIBLE else View.GONE
        }

        viewModel.activeCows.observe(viewLifecycleOwner) { cowList ->
            cows = cowList
        }

        binding.fabAddMilk.setOnClickListener {
            showAddMilkDialog()
        }
    }

    private fun showAddMilkDialog() {
        if (cows.isEmpty()) {
            Snackbar.make(binding.root, "Please add cows first!", Snackbar.LENGTH_SHORT).show()
            return
        }

        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_milk, null)
        val spinnerCow = dialogView.findViewById<Spinner>(R.id.spinnerCow)
        val etLiters = dialogView.findViewById<EditText>(R.id.etLiters)
        val etFat = dialogView.findViewById<EditText>(R.id.etFat)
        val etSnf = dialogView.findViewById<EditText>(R.id.etSnf)
        val etRate = dialogView.findViewById<EditText>(R.id.etRate)
        val tvDate = dialogView.findViewById<TextView>(R.id.tvDate)
        val btnDate = dialogView.findViewById<Button>(R.id.btnPickDate)

        val cowNames = cows.map { it.name }
        spinnerCow.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, cowNames)

        tvDate.text = "${selectedDate.get(Calendar.DAY_OF_MONTH)}/${selectedDate.get(Calendar.MONTH) + 1}/${selectedDate.get(Calendar.YEAR)}"

        btnDate.setOnClickListener {
            DatePickerDialog(requireContext(), { _, y, m, d ->
                selectedDate.set(y, m, d)
                tvDate.text = "$d/${m + 1}/$y"
            }, selectedDate.get(Calendar.YEAR), selectedDate.get(Calendar.MONTH), selectedDate.get(Calendar.DAY_OF_MONTH)).show()
        }

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("🥛 Add Milk Entry")
            .setView(dialogView)
            .setPositiveButton("Add Entry") { _, _ ->
                val cow = cows[spinnerCow.selectedItemPosition]
                val liters = etLiters.text.toString().toDoubleOrNull() ?: 0.0
                val fat = etFat.text.toString().toDoubleOrNull() ?: 0.0
                val snf = etSnf.text.toString().toDoubleOrNull() ?: 0.0
                val rate = etRate.text.toString().toDoubleOrNull() ?: 0.0

                if (liters > 0 && rate > 0) {
                    val entry = MilkEntry(
                        cowId = cow.id,
                        cowName = cow.name,
                        liters = liters,
                        fatPercent = fat,
                        snfPercent = snf,
                        ratePerLiter = rate,
                        date = selectedDate.timeInMillis,
                        month = selectedDate.get(Calendar.MONTH) + 1,
                        year = selectedDate.get(Calendar.YEAR)
                    )
                    viewModel.insertMilkEntry(entry)
                    Snackbar.make(binding.root, "Entry added ✓", Snackbar.LENGTH_SHORT).show()
                } else {
                    Snackbar.make(binding.root, "Please fill all fields", Snackbar.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
