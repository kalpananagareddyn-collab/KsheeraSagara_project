package com.mindmatrix.ksheerasagara.data.repository

import androidx.lifecycle.LiveData
import com.mindmatrix.ksheerasagara.data.dao.CowDao
import com.mindmatrix.ksheerasagara.data.dao.ExpenseDao
import com.mindmatrix.ksheerasagara.data.dao.MilkEntryDao
import com.mindmatrix.ksheerasagara.data.entities.Cow
import com.mindmatrix.ksheerasagara.data.entities.ExpenseCategory
import com.mindmatrix.ksheerasagara.data.entities.ExpenseEntry
import com.mindmatrix.ksheerasagara.data.entities.MilkEntry

class DairyRepository(
    private val cowDao: CowDao,
    private val milkEntryDao: MilkEntryDao,
    private val expenseDao: ExpenseDao
) {
    // Cows
    val activeCows: LiveData<List<Cow>> = cowDao.getActiveCows()
    val allCows: LiveData<List<Cow>> = cowDao.getAllCows()

    suspend fun insertCow(cow: Cow): Long = cowDao.insert(cow)
    suspend fun updateCow(cow: Cow) = cowDao.update(cow)
    suspend fun deleteCow(cow: Cow) = cowDao.delete(cow)
    suspend fun getCowById(id: Long): Cow? = cowDao.getCowById(id)

    // Milk Entries
    fun getEntriesForMonth(month: Int, year: Int) = milkEntryDao.getEntriesForMonth(month, year)
    fun getAllMilkEntries() = milkEntryDao.getAllEntries()
    fun getTotalIncomeForMonth(month: Int, year: Int) = milkEntryDao.getTotalIncomeForMonth(month, year)
    fun getTotalIncomeForCowMonth(cowId: Long, month: Int, year: Int) = milkEntryDao.getTotalIncomeForCowMonth(cowId, month, year)
    suspend fun insertMilkEntry(entry: MilkEntry): Long = milkEntryDao.insert(entry)
    suspend fun deleteMilkEntry(entry: MilkEntry) = milkEntryDao.delete(entry)
    fun getMilkEntriesForCow(cowId: Long) = milkEntryDao.getEntriesForCow(cowId)

    // Expenses
    fun getExpensesForMonth(month: Int, year: Int) = expenseDao.getExpensesForMonth(month, year)
    fun getAllExpenses() = expenseDao.getAllExpenses()
    fun getTotalExpensesForMonth(month: Int, year: Int) = expenseDao.getTotalExpensesForMonth(month, year)
    fun getTotalExpensesForCowMonth(cowId: Long, month: Int, year: Int) = expenseDao.getTotalExpensesForCowMonth(cowId, month, year)
    fun getExpensesByCategory(category: ExpenseCategory, month: Int, year: Int) = expenseDao.getExpensesByCategory(category, month, year)
    suspend fun insertExpense(entry: ExpenseEntry): Long = expenseDao.insert(entry)
    suspend fun deleteExpense(entry: ExpenseEntry) = expenseDao.delete(entry)
    fun getExpensesForCowMonth(cowId: Long, month: Int, year: Int) = expenseDao.getExpensesForCowMonth(cowId, month, year)
}
