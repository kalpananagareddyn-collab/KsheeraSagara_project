package com.mindmatrix.ksheerasagara.ui.expense

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.mindmatrix.ksheerasagara.R
import com.mindmatrix.ksheerasagara.data.entities.Cow
import com.mindmatrix.ksheerasagara.data.entities.ExpenseCategory
import com.mindmatrix.ksheerasagara.data.entities.ExpenseEntry
import com.mindmatrix.ksheerasagara.databinding.FragmentExpenseBinding
import com.mindmatrix.ksheerasagara.viewmodel.ExpenseViewModel
import com.mindmatrix.ksheerasagara.viewmodel.ExpenseViewModelFactory
import java.util.*

class ExpenseFragment : Fragment() {

    private var _binding: FragmentExpenseBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: ExpenseViewModel
    private lateinit var adapter: ExpenseAdapter
    private var cows: List<Cow> = emptyList()
    private var selectedDate = Calendar.getInstance()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentExpenseBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(this, ExpenseViewModelFactory(requireActivity().application))[ExpenseViewModel::class.java]

        adapter = ExpenseAdapter { entry ->
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Delete Expense")
                .setMessage("Delete this expense entry?")
                .setPositiveButton("Delete") { _, _ -> viewModel.deleteExpense(entry) }
                .setNegativeButton("Cancel", null)
                .show()
        }

        binding.rvExpenses.layoutManager = LinearLayoutManager(requireContext())
        binding.rvExpenses.adapter = adapter

        val cal = Calendar.getInstance()
        viewModel.getExpensesForMonth(cal.get(Calendar.MONTH) + 1, cal.get(Calendar.YEAR)).observe(viewLifecycleOwner) { entries ->
            adapter.submitList(entries)
            binding.tvEmptyState.visibility = if (entries.isEmpty()) View.VISIBLE else View.GONE
        }

        viewModel.activeCows.observe(viewLifecycleOwner) { cowList -> cows = cowList }

        binding.fabAddExpense.setOnClickListener { showAddExpenseDialog() }
    }

    private fun showAddExpenseDialog() {
        if (cows.isEmpty()) {
            Snackbar.make(binding.root, "Please add cows first!", Snackbar.LENGTH_SHORT).show()
            return
        }

        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_expense, null)
        val spinnerCow = dialogView.findViewById<Spinner>(R.id.spinnerCow)
        val spinnerCategory = dialogView.findViewById<Spinner>(R.id.spinnerCategory)
        val etAmount = dialogView.findViewById<EditText>(R.id.etAmount)
        val etDesc = dialogView.findViewById<EditText>(R.id.etDescription)
        val tvDate = dialogView.findViewById<TextView>(R.id.tvDate)
        val btnDate = dialogView.findViewById<Button>(R.id.btnPickDate)

        spinnerCow.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, cows.map { it.name })
        val categories = ExpenseCategory.values()
        spinnerCategory.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, categories.map { "${it.emoji} ${it.displayName}" })

        tvDate.text = "${selectedDate.get(Calendar.DAY_OF_MONTH)}/${selectedDate.get(Calendar.MONTH) + 1}/${selectedDate.get(Calendar.YEAR)}"
        btnDate.setOnClickListener {
            DatePickerDialog(requireContext(), { _, y, m, d ->
                selectedDate.set(y, m, d)
                tvDate.text = "$d/${m + 1}/$y"
            }, selectedDate.get(Calendar.YEAR), selectedDate.get(Calendar.MONTH), selectedDate.get(Calendar.DAY_OF_MONTH)).show()
        }

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("💸 Add Expense")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val cow = cows[spinnerCow.selectedItemPosition]
                val category = categories[spinnerCategory.selectedItemPosition]
                val amount = etAmount.text.toString().toDoubleOrNull() ?: 0.0
                val desc = etDesc.text.toString()

                if (amount > 0) {
                    viewModel.insertExpense(
                        ExpenseEntry(
                            cowId = cow.id, cowName = cow.name,
                            category = category, amount = amount,
                            description = desc,
                            date = selectedDate.timeInMillis,
                            month = selectedDate.get(Calendar.MONTH) + 1,
                            year = selectedDate.get(Calendar.YEAR)
                        )
                    )
                    Snackbar.make(binding.root, "Expense added ✓", Snackbar.LENGTH_SHORT).show()
                } else {
                    Snackbar.make(binding.root, "Enter a valid amount", Snackbar.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
