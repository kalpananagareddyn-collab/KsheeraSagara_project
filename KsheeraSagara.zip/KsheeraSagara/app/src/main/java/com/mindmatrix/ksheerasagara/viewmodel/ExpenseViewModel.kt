package com.mindmatrix.ksheerasagara.viewmodel

import android.app.Application
import androidx.lifecycle.*
import com.mindmatrix.ksheerasagara.KsheeraApp
import com.mindmatrix.ksheerasagara.data.entities.Cow
import com.mindmatrix.ksheerasagara.data.entities.ExpenseEntry
import com.mindmatrix.ksheerasagara.data.repository.DairyRepository
import kotlinx.coroutines.launch

class ExpenseViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: DairyRepository = (application as KsheeraApp).repository

    val activeCows: LiveData<List<Cow>> = repository.activeCows
    val allExpenses: LiveData<List<ExpenseEntry>> = repository.getAllExpenses()

    fun insertExpense(entry: ExpenseEntry) = viewModelScope.launch {
        repository.insertExpense(entry)
    }

    fun deleteExpense(entry: ExpenseEntry) = viewModelScope.launch {
        repository.deleteExpense(entry)
    }

    fun getExpensesForMonth(month: Int, year: Int) = repository.getExpensesForMonth(month, year)
}

class ExpenseViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ExpenseViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ExpenseViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
