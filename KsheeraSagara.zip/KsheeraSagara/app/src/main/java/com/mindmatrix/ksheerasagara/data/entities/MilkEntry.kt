package com.mindmatrix.ksheerasagara.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "milk_entries")
data class MilkEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val cowId: Long,
    val cowName: String,
    val liters: Double,
    val fatPercent: Double,
    val snfPercent: Double,
    val ratePerLiter: Double,
    val date: Long, // timestamp
    val month: Int,
    val year: Int
) {
    val totalPayment: Double get() = liters * ratePerLiter
}
