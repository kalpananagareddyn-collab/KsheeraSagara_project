package com.mindmatrix.ksheerasagara.ui.expense

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.mindmatrix.ksheerasagara.data.entities.ExpenseEntry
import com.mindmatrix.ksheerasagara.databinding.ItemExpenseEntryBinding
import java.text.SimpleDateFormat
import java.util.*

class ExpenseAdapter(private val onDelete: (ExpenseEntry) -> Unit) :
    ListAdapter<ExpenseEntry, ExpenseAdapter.ViewHolder>(DIFF) {

    inner class ViewHolder(private val b: ItemExpenseEntryBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(e: ExpenseEntry) {
            val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
            b.tvDate.text = sdf.format(Date(e.date))
            b.tvCowName.text = "🐄 ${e.cowName}"
            b.tvCategory.text = "${e.category.emoji} ${e.category.displayName}"
            b.tvAmount.text = "₹%.2f".format(e.amount)
            b.tvDescription.text = e.description.ifEmpty { "—" }
            b.btnDelete.setOnClickListener { onDelete(e) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemExpenseEntryBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(h: ViewHolder, pos: Int) = h.bind(getItem(pos))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<ExpenseEntry>() {
            override fun areItemsTheSame(a: ExpenseEntry, b: ExpenseEntry) = a.id == b.id
            override fun areContentsTheSame(a: ExpenseEntry, b: ExpenseEntry) = a == b
        }
    }
}
